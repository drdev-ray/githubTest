import { decide, DomainError, type Command } from '../domain/commands.ts';
import type { CommandReceipt, SnapshotRepository } from '../ports/repository.ts';
import { logicalEventFingerprint, stableStringify, TransportCommitError } from '../adapters/sheets.ts';

export class WriterError extends Error {
  readonly code:string;
  readonly details:Record<string,unknown>;
  constructor(code:string, details:Record<string,unknown>={}) { super(code); this.code=code; this.details=details; this.name='WriterError'; }
}

type JournalStatus='PREPARED'|'UNKNOWN'|'COMMITTED';
export interface JournalRecord { idempotencyKey:string; payloadHash:string; commandId:string; status:JournalStatus; retryable?:boolean; expectedEntityIds?:string[]; expectedWorkspaceVersion?:number; expectedEventFingerprint?:string; receipt?:CommandReceipt; }
export interface WriterJournal { get(key:string):Promise<JournalRecord|undefined>; findByCommandId(commandId:string):Promise<JournalRecord|undefined>; put(record:JournalRecord):Promise<void>; uncertain():Promise<JournalRecord[]>; }
export class InMemoryJournal implements WriterJournal {
  private records=new Map<string,JournalRecord>();
  async get(k:string){ return structuredClone(this.records.get(k)); }
  async findByCommandId(commandId:string){ return structuredClone([...this.records.values()].find(record=>record.commandId===commandId)); }
  peek(k:string){ return this.records.get(k); }
  async put(r:JournalRecord){ this.records.set(r.idempotencyKey,structuredClone(r)); }
  async uncertain(){ return [...this.records.values()].filter(r=>r.status==='UNKNOWN' || (r.status==='PREPARED' && r.retryable===false)).map(r=>structuredClone(r)); }
}

export interface WriterOptions { principalId:string; reportedActorId?:string; reason:string; sourceUri?:string; now:()=>string; id:()=>string; }
export interface CommandAuditMetadata { principalId:string; reportedActorId?:string; reason:string; sourceUri?:string; }
export interface CommitInput { idempotencyKey:string; command:Command; audit?:CommandAuditMetadata; }

async function sha256Hex(text:string):Promise<string>{
  const data=new TextEncoder().encode(text);
  const digest=await crypto.subtle.digest('SHA-256',data);
  return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('');
}

export class WorkspaceWriter {
  private tail:Promise<void>=Promise.resolve();
  private readonly repo: SnapshotRepository;
  private readonly journal: WriterJournal;
  private readonly options: WriterOptions;
  constructor(repo:SnapshotRepository, journal:WriterJournal, options:WriterOptions){ this.repo=repo; this.journal=journal; this.options=options; }

  private async locked<T>(fn:()=>Promise<T>):Promise<T>{
    let release!:()=>void; const next=new Promise<void>(r=>release=r); const prev=this.tail; this.tail=next; await prev;
    try{return await fn();}finally{release();}
  }

  async commit(input:CommitInput):Promise<CommandReceipt>{ return this.locked(()=>this.commitLocked(input)); }

  async getCommandStatus(commandId:string):Promise<{command_id:string;status:'PREPARED'|'UNKNOWN'|'SUCCEEDED'|'REJECTED';result?:CommandReceipt;reason?:string}>{
    const durable=await this.repo.findCommandById(commandId);
    if(durable) return {command_id:commandId,status:'SUCCEEDED',result:durable};
    const record=await this.journal.findByCommandId(commandId);
    if(!record) throw new WriterError('NOT_FOUND',{commandId});
    if(record.status==='COMMITTED' && record.receipt) return {command_id:commandId,status:'SUCCEEDED',result:record.receipt};
    return {command_id:commandId,status:record.status==='UNKNOWN'?'UNKNOWN':'PREPARED'};
  }

  private async reconcile(record:JournalRecord):Promise<CommandReceipt|null>{
    const found=await this.repo.findCommand(record.idempotencyKey,record.payloadHash);
    if(!found) return null;
    const expectedIds=[...(record.expectedEntityIds ?? [])].sort();
    const foundIds=[...found.changedEntityIds].sort();
    const mismatched =
      found.commandId !== record.commandId ||
      (record.expectedWorkspaceVersion !== undefined && found.workspaceVersion !== record.expectedWorkspaceVersion) ||
      (record.expectedEventFingerprint !== undefined && found.eventFingerprint !== record.expectedEventFingerprint) ||
      (record.expectedEntityIds !== undefined && stableStringify(foundIds) !== stableStringify(expectedIds));
    if(mismatched) throw new WriterError('INTEGRITY_ERROR',{idempotencyKey:record.idempotencyKey,commandId:record.commandId});
    const receipt={...found,replayed:true};
    await this.journal.put({...record,status:'COMMITTED',receipt});
    return receipt;
  }

  private async commitLocked(input:CommitInput):Promise<CommandReceipt>{
    const payloadHash=await sha256Hex(stableStringify(input.command));
    const existing=await this.journal.get(input.idempotencyKey);
    if(existing){
      if(existing.payloadHash!==payloadHash) throw new WriterError('IDEMPOTENCY_CONFLICT');
      if(existing.status==='COMMITTED' && existing.receipt) return {...existing.receipt,replayed:true};
      const reconciled=await this.reconcile(existing); if(reconciled) return reconciled;
      if(existing.status==='UNKNOWN' || (existing.status==='PREPARED' && existing.retryable===false)) throw new WriterError('WRITE_OUTCOME_UNKNOWN');
    } else {
      try {
        const durableReplay=await this.repo.findCommand(input.idempotencyKey,payloadHash);
        if(durableReplay) return {...durableReplay,replayed:true};
      } catch(e) {
        if(e instanceof Error && e.message==='IDEMPOTENCY_CONFLICT') throw new WriterError('IDEMPOTENCY_CONFLICT');
        throw e;
      }
    }
    for(const uncertain of await this.journal.uncertain()){
      const reconciled=await this.reconcile(uncertain); if(!reconciled) throw new WriterError('WRITER_HALTED_UNKNOWN',{idempotencyKey:uncertain.idempotencyKey});
    }
    const snapshot=await this.repo.readSnapshot();
    const now=this.options.now();
    let changeSet;
    try { changeSet=decide(snapshot,input.command,now); }
    catch(e){ if(e instanceof DomainError) throw e; throw e; }
    const commandId=existing?.commandId ?? `C-${this.options.id()}`;
    const expectedEntityIds=[...new Set(changeSet.events.map(e=>e.entity_id))].sort();
    const prepared:JournalRecord={idempotencyKey:input.idempotencyKey,payloadHash,commandId,status:'PREPARED',retryable:true,expectedEntityIds,expectedWorkspaceVersion:snapshot.settings.workspace_version+1,expectedEventFingerprint:logicalEventFingerprint(changeSet.events)};
    await this.journal.put(prepared);
    const dispatched={...prepared,retryable:false};
    await this.journal.put(dispatched);
    try{
      const audit = input.audit ?? { principalId:this.options.principalId, reportedActorId:this.options.reportedActorId, reason:this.options.reason, sourceUri:this.options.sourceUri };
      const receipt=await this.repo.commitAtomic(changeSet,{commandId,idempotencyKey:input.idempotencyKey,payloadHash,principalId:audit.principalId,reportedActorId:audit.reportedActorId,reason:audit.reason,sourceUri:audit.sourceUri,now,expectedWorkspaceVersion:snapshot.settings.workspace_version});
      await this.journal.put({...dispatched,status:'COMMITTED',retryable:false,receipt});
      return receipt;
    }catch(e){
      if(e instanceof TransportCommitError && e.outcome==='UNKNOWN'){
        await this.journal.put({...dispatched,status:'UNKNOWN',retryable:false});
        throw new WriterError('WRITE_OUTCOME_UNKNOWN');
      }
      if(e instanceof TransportCommitError && e.outcome==='NOT_APPLIED') await this.journal.put({...prepared,retryable:true});
      throw e;
    }
  }
}
