import { sheetSchemaErrors, type SheetSnapshot } from '../src/adapters/sheets.ts';

export function verifySchema(snapshot:SheetSnapshot):{ok:boolean;errors:string[]} {
  const errors=sheetSchemaErrors(snapshot);
  return {ok:errors.length===0,errors};
}
