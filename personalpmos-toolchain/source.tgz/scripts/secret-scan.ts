import { readFile, readdir } from 'node:fs/promises';
import { extname, join, relative } from 'node:path';
import { pathToFileURL } from 'node:url';

export interface SecretFinding { kind:string; index:number; }
const PATTERNS:Array<[string,RegExp]> = [
  ['PRIVATE_KEY',/-----BEGIN (?:RSA |EC |OPENSSH |)?PRIVATE KEY-----/g],
  ['AWS_ACCESS_KEY',/\bAKIA[0-9A-Z]{16}\b/g],
  ['GITHUB_TOKEN',/\bgh[pousr]_[A-Za-z0-9]{30,}\b/g],
  ['OPENAI_KEY',/\bsk-[A-Za-z0-9_-]{20,}\b/g],
  ['GOOGLE_API_KEY',/\bAIza[0-9A-Za-z_-]{30,}\b/g],
];

export function findHighRiskSecrets(text:string):SecretFinding[] {
  const findings:SecretFinding[]=[];
  for(const [kind,pattern] of PATTERNS){
    pattern.lastIndex=0;
    for(let match=pattern.exec(text);match;match=pattern.exec(text)) findings.push({kind,index:match.index});
  }
  return findings.sort((a,b)=>a.index-b.index || a.kind.localeCompare(b.kind));
}

const TEXT_EXTENSIONS=new Set(['.ts','.js','.mjs','.json','.yaml','.yml','.md','.txt','.jsonc']);
async function filesUnder(root:string):Promise<string[]> {
  const out:string[]=[];
  async function walk(dir:string):Promise<void>{
    for(const entry of await readdir(dir,{withFileTypes:true})){
      if(['.git','.worktrees','node_modules','dist','coverage','tests'].includes(entry.name)) continue;
      const path=join(dir,entry.name);
      if(entry.isDirectory()) await walk(path);
      else if(TEXT_EXTENSIONS.has(extname(entry.name)) || ['package.json','tsconfig.json'].includes(entry.name)) out.push(path);
    }
  }
  await walk(root);
  return out;
}

async function main():Promise<void>{
  const root=process.cwd();
  const findings:Array<{file:string;kind:string;index:number}>=[];
  for(const file of await filesUnder(root)){
    const text=await readFile(file,'utf8');
    for(const finding of findHighRiskSecrets(text)) findings.push({file:relative(root,file),...finding});
  }
  if(findings.length){
    for(const finding of findings) console.error(`${finding.file}: ${finding.kind} at ${finding.index}`);
    process.exitCode=1;
    return;
  }
  console.log('No high-risk secret patterns found.');
}

if(import.meta.url===pathToFileURL(process.argv[1] ?? '').href) await main();
